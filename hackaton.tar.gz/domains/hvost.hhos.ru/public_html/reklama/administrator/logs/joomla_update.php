#
#<?php die('Forbidden.'); ?>
#Date: 2020-08-21 19:45:47 UTC
#Software: Joomla Platform 13.1.0 Stable [ Curiosity ] 24-Apr-2013 00:00 GMT

#Fields: datetime	priority clientip	category	message
2020-08-21T19:45:47+00:00	INFO 91.214.131.156	update	Обновление запущено пользователем Super User (ID 403). Предыдущая версия: 3.9.11.
2020-08-21T19:45:51+00:00	INFO 91.214.131.156	update	Загрузка пакета обновления с https://s3-us-west-2.amazonaws.com/joomla-official-downloads/joomladownloads/joomla3/Joomla_3.9.20-Stable-Update_Package.zip?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAIZ6S3Q3YQHG57ZRA%2F20200821%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20200821T194544Z&X-Amz-Expires=60&X-Amz-SignedHeaders=host&X-Amz-Signature=3dc981157e339aaf9ba5193409c0849cdeadff98ed05196faf3981dfbb0c733d.
2020-08-21T19:45:55+00:00	INFO 91.214.131.156	update	Файл Joomla_3.9.20-Stable-Update_Package.zip успешно загружен.
2020-08-21T19:45:55+00:00	INFO 91.214.131.156	update	Начало установки новой версии.
2020-08-21T19:46:08+00:00	INFO 91.214.131.156	update	Завершение установки.
2020-08-21T19:46:09+00:00	INFO 91.214.131.156	update	Выполнен запрос из файла 3.9.16-2020-02-15. Текст запроса: ALTER TABLE `#__categories` MODIFY `description` mediumtext;.
2020-08-21T19:46:09+00:00	INFO 91.214.131.156	update	Выполнен запрос из файла 3.9.16-2020-02-15. Текст запроса: ALTER TABLE `#__categories` MODIFY `params` text;.
2020-08-21T19:46:09+00:00	INFO 91.214.131.156	update	Выполнен запрос из файла 3.9.16-2020-02-15. Текст запроса: ALTER TABLE `#__fields` MODIFY `default_value` text;.
2020-08-21T19:46:09+00:00	INFO 91.214.131.156	update	Выполнен запрос из файла 3.9.16-2020-02-15. Текст запроса: ALTER TABLE `#__fields_values` MODIFY `value` text;.
2020-08-21T19:46:09+00:00	INFO 91.214.131.156	update	Выполнен запрос из файла 3.9.16-2020-02-15. Текст запроса: ALTER TABLE `#__finder_links` MODIFY `description` text;.
2020-08-21T19:46:09+00:00	INFO 91.214.131.156	update	Выполнен запрос из файла 3.9.16-2020-02-15. Текст запроса: ALTER TABLE `#__modules` MODIFY `content` text;.
2020-08-21T19:46:09+00:00	INFO 91.214.131.156	update	Выполнен запрос из файла 3.9.16-2020-02-15. Текст запроса: ALTER TABLE `#__ucm_content` MODIFY `core_body` mediumtext;.
2020-08-21T19:46:09+00:00	INFO 91.214.131.156	update	Выполнен запрос из файла 3.9.16-2020-02-15. Текст запроса: ALTER TABLE `#__ucm_content` MODIFY `core_params` text;.
2020-08-21T19:46:10+00:00	INFO 91.214.131.156	update	Выполнен запрос из файла 3.9.16-2020-02-15. Текст запроса: ALTER TABLE `#__ucm_content` MODIFY `core_images` text;.
2020-08-21T19:46:10+00:00	INFO 91.214.131.156	update	Выполнен запрос из файла 3.9.16-2020-02-15. Текст запроса: ALTER TABLE `#__ucm_content` MODIFY `core_urls` text;.
2020-08-21T19:46:10+00:00	INFO 91.214.131.156	update	Выполнен запрос из файла 3.9.16-2020-02-15. Текст запроса: ALTER TABLE `#__ucm_content` MODIFY `core_metakey` text;.
2020-08-21T19:46:10+00:00	INFO 91.214.131.156	update	Выполнен запрос из файла 3.9.16-2020-02-15. Текст запроса: ALTER TABLE `#__ucm_content` MODIFY `core_metadesc` text;.
2020-08-21T19:46:10+00:00	INFO 91.214.131.156	update	Выполнен запрос из файла 3.9.16-2020-03-04. Текст запроса: ALTER TABLE `#__users` DROP INDEX `username`;.
2020-08-21T19:46:10+00:00	INFO 91.214.131.156	update	Выполнен запрос из файла 3.9.16-2020-03-04. Текст запроса: ALTER TABLE `#__users` ADD UNIQUE INDEX `idx_username` (`username`);.
2020-08-21T19:46:10+00:00	INFO 91.214.131.156	update	Выполнен запрос из файла 3.9.19-2020-05-16. Текст запроса: ALTER TABLE `#__ucm_content` MODIFY `core_title` varchar(400) NOT NULL DEFAULT '.
2020-08-21T19:46:10+00:00	INFO 91.214.131.156	update	Выполнен запрос из файла 3.9.19-2020-06-01. Текст запроса: INSERT INTO `#__postinstall_messages` (`extension_id`, `title_key`, `description.
2020-08-21T19:46:10+00:00	INFO 91.214.131.156	update	Удаление устаревших файлов и директорий.
2020-08-21T19:46:12+00:00	INFO 91.214.131.156	update	Очистка после установки.
2020-08-21T19:46:12+00:00	INFO 91.214.131.156	update	Обновление до версии 3.9.20 завершено.
