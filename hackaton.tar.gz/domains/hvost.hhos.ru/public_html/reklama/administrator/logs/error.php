#
#<?php die('Forbidden.'); ?>
#Date: 2020-08-21 19:44:58 UTC
#Software: Joomla Platform 13.1.0 Stable [ Curiosity ] 24-Apr-2013 00:00 GMT

#Fields: datetime	priority clientip	category	message
2020-08-21T19:44:58+00:00	INFO 91.214.131.156	joomlafailure	Пустое поле пароля не допускается.
